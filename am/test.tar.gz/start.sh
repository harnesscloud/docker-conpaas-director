#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
args=( "$@" )

echo 'staring test...' >> /root/test.out
#(cd $DIR/application ; ./RTMDemoCPU "tests/${args[0]}" >> /root/rtm.out )
sleep ${args[0]}
exit 0
