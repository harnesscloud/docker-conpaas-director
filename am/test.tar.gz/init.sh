#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
args=( "$@" )

echo 'initializing...' >> /root/test.out
#(cd $DIR/application ; ./GenerateData "tests/${args[0]}" >> /root/rtm.out )


